#!/usr/bin/env python2

import os, sys
import io
import collections

from datetime import datetime
import json

import pygame.midi as midi
import pygame

from timeit import default_timer as timer
import time
import math

class Tee(object):
    def __init__(self, *files):
        self.files = files
    def write(self, obj):
        for f in self.files:
            f.write(obj)
            f.flush() # If you want the output to be visible immediately
    def flush(self) :
        for f in self.files:
            f.flush()

f = open('./log-files/configuration-Log.txt', 'a')
original = sys.stdout
sys.stdout = Tee(sys.stdout, f)

#------------------------------------------------------------------------------
#==============================================================================
#		start MIDI
#==============================================================================
notes = ["C","C#-Db","D","D#-Eb","E","F","F#-Gb","G","G#-Ab","A","A#-Bb","B"]
virtualKeyboard = {}
keyrange = 0
data = {}

for i in range(0,128):

	if i == (keyrange+len(notes)):
		keyrange += len(notes)

	virtualKeyboard[i] = notes[(i-keyrange)]

with open('./saved-files/virtual_keyboard.json', 'w') as outfile:
    json.dump(virtualKeyboard, outfile)

pygame.init()
pygame.fastevent.init()

inputfilter = {'y':True,'Y':True,'yes':True,'Yes':True,'n':False,'N':False,'no':False,'No':False,'x':'done','X':'done'}
OfOnarray = ['Off','On']

ipDev = 0
opDev = 0

isMidi = False
x = ''
player = '';
#------------------------------------------------------------------------------
#==============================================================================
#		Interface
#==============================================================================

def midiresp():

	global isMidi
	global x
	global data
	global player
	CheckTimer = 10+timer()

	#print('Checking Output- type a number between 50 and 100')
	#noteToPlay = input()
	#player.note_off(noteToPlay, 120, 1)
	#player.note_on(noteToPlay, 120, 1)
	#time.sleep(3)
	#player.note_off(noteToPlay, 120, 1)
	player.abort()
	player.close()

	print('play a note to check if Input is working.....')
	print('')
	print('')
	while True:

		#print(CheckTimer)
		if x.poll():

			midiEvent = x.read(1)[0]
			noteSW = midiEvent[0][0]
			note = midiEvent[0][1]
			vel = midiEvent[0][2]

			if midiEvent[0][2] != 0:

				sys.stdout.write('\x1b[1A')
				sys.stdout.write('\x1b[2K')
				print(midiEvent)
				isMidi = True
				print('Check, note = '+virtualKeyboard[note])
				print('')


		sys.stdout.write('\x1b[1A')
		sys.stdout.write('\x1b[2K')
		print(' --- Check will stop in '+str(round(CheckTimer-timer()))+' sec --- ')

		if round(CheckTimer-timer()) <= 0:

			if isMidi == False:
				awnser = raw_input('There was no MIDI, do you want to check again or reset the input (Y = check again/ N = reset input/ X = done) ?')
			else:
				awnser = raw_input('Your MIDI device is set, select an option (Y = check again/ N = reset input/ X = done) ?')

			try:
				awnser = inputfilter[str(awnser)]
			except:
				awnser = False

			print(awnser)

			if awnser == True:

				isMidi = False
				CheckTimer = 10+timer()

			elif awnser == False:

				x.close()
				midi.quit()

				isMidi = False
				inputFN()
				break

			else:

				x.close()
				player.abort()
				player.close()
				midi.quit()

				break

	with open('./saved-files/keyboard.json', 'w') as outfile:
		json.dump(data, outfile)

	print('All done...')
	#writeConfig()

#------------------------------------------------------------------------------
#==============================================================================
#		find MIDI output
#==============================================================================

def outputFN():

	global opDev
	global player
	global data

	if findinput == True:

		print ('Type number of output:')
		opDev = input()

	else:

		print ('searching MIDI deviceses...')
		opDev = midi.get_default_output_id()

	player = midi.Output(opDev,0,4096)
	player.set_instrument(1,1)
	print(midi.get_device_info(opDev))

	data["dev_out"] = str(midi.get_device_info(opDev))
	data["out"] = opDev

	midiresp()

#------------------------------------------------------------------------------
#==============================================================================
#		find MIDI input
#==============================================================================

def inputFN():

	global ipDev
	global x
	global findinput
	global data

	findinput = raw_input('Do you want to manualy search for MIDI input(y/n)? ')
	midi.init()

	try:
		findinput = inputfilter[findinput]
	except:
		findinput = False

	file = open('./saved-files/devices.txt','w')

	for i in range(midi.get_count()):
		file.write(str(i)+': '+str(midi.get_device_info(i))+' \n')

	file.close()

	if findinput == True:

		print ('MIDI devices')
		data["default_in"] = str(midi.get_default_input_id())
		data["default_out"] = str(midi.get_default_output_id())

		while midi.get_count() <= 0:
			print('Error - no devises found')

		for i in range(midi.get_count()):

			print (str(i)+': '+str(midi.get_device_info(i)[0])+'-'+str(midi.get_device_info(i)[1]))

			if int(midi.get_device_info(i)[2]) == 1:
				print ('  -  Input')
				if i == int(midi.get_default_input_id()):
				 	print ('  -  Default input')

			elif int(midi.get_device_info(i)[3]) == 1:
				print ('  -  Output')
				if i == int(midi.get_default_output_id()):
				 	print ('  -  Default output')

			else:
				print ('  -  not recognised')
				print (str(midi.get_device_info(i)))

		print ('Type number of input:')
		ipDev = input()

	else:

		print ('searching MIDI deviceses...')
		ipDev = midi.get_default_input_id()

	if midi.get_device_info(ipDev)[2] == 1:

		x = midi.Input(ipDev,0)

		class getX:
			def __getitem__(self,index):
				print (x)

		x.read(1)
		print(midi.get_device_info(ipDev))
		data["dev_in"] = str(midi.get_device_info(ipDev))

	elif midi.get_device_info(ipDev)[2] == 0:

		print('This device is not a valid input, it is an output')

	elif int(ipDev >= midi.get_count()):

		print('There is no device with id '+str(ipDev))

	else:

		print('Unknown error while searching for ('+str(ipDev)+')')

	data["in"] = ipDev
	outputFN()

inputFN()

#------------------------------------------------------------------------------
#==============================================================================
