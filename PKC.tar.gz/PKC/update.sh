#!/bin/bash

echo $'\n\n\t updating software: \n' >> log-files/run-Log.txt
date '+%Y-%m-%d %H:%M:%S' >> log-files/run-Log.txt
echo $'\n\n' >> log-files/run-Log.txt
echo ${OSSTR} >> log-files/installation-Log.txt

echo '------------------------------------------------' >> log-files/installation-Log.txt

echo '------------------------------------------------'
echo '================================================'
echo 'Updating homebrew...'
echo '================================================'
echo $'\n\t ------ Homebrew  ------ \n' >> log-files/installation-Log.txt

brew update 2>&1 | tee -a log-files/installation-Log.txt
brew upgrade 2>&1 | tee -a log-files/installation-Log.txt
brew doctor 2>&1 | tee -a log-files/installation-Log.txt
brew cleanup -n 2>&1 | tee -a log-files/installation-Log.txt

#brew cask reinstall xquartz 2>&1 | tee -a log-files/installation-Log.txt

echo '------------------------------------------------'
echo '================================================'
echo 'Updating python pip...'
echo '================================================'
echo $'\n\t ------ python2 ------ \n' >> log-files/installation-Log.txt

sudo pip install --upgrade pip 2>&1 | tee -a log-files/installation-Log.txt

echo '------------------------------------------------'
echo '================================================'
echo 'Updating NodeJS...'
echo '================================================'
echo $'\n\t ------ NodeJS ------ \n' >> log-files/installation-Log.txt

brew upgrade node 2>&1 | tee -a log-files/installation-Log.txt
brew upgrade npm 2>&1 | tee -a log-files/installation-Log.txt

echo $'\n\t ------ Brew modual list ------ ' >> log-files/installation-Log.txt
brew list 2>&1 | tee -a log-files/installation-Log.txt

echo $'\n\t ------ Python modual list ------ ' >> log-files/installation-Log.txt
pip2 list 2>&1 | tee -a log-files/installation-Log.txt

echo '------------------------------------------------'
echo '================================================'
echo 'Everything is up to date!'
echo '================================================'
