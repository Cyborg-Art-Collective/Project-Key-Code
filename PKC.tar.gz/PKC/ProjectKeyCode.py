#!/usr/bin/env python2

import os, sys
import io
import collections

from datetime import datetime
from socketIO_client import SocketIO, BaseNamespace
import json

import pygame.midi as midi
import pygame

import time
import math

import threading
from thread import *

class Tee(object):
    def __init__(self, *files):
        self.files = files
    def write(self, obj):
        for f in self.files:
            f.write(obj)
            f.flush() # If you want the output to be visible immediately
    def flush(self) :
        for f in self.files:
            f.flush()

f = open('./log-files/run-Log.txt', 'a')
original = sys.stdout
sys.stdout = Tee(sys.stdout, f)

PKCmsg = ''
PKCmidi= ''
lastMsgTime = 0
lastMsg = ''
senddata = ''
capslock = False

#------------------------------------------------------------------------------
#==============================================================================
#		Timer
#==============================================================================

print ('--------------------------------------------------------')
print ('Starting PKC interface')
print ('========================================================')
print ('--------------------------------------------------------')

timerStart = time.time()
print ('Start timer ___ '+str(time.time()-timerStart)+' ___ ')

#------------------------------------------------------------------------------
#==============================================================================

#------------------------------------------------------------------------------
#==============================================================================
#		Virtual Keyboard
#==============================================================================

class VirKey:

	KeyCount = 128

	try:
		len(VirtualKeyboard)

	except KeyboardInterrupt:
		try:
			sys.exit(0)
		except SystemExit:
			os._exit(0)

	except:

		print ('--------------------------------------------------------')
		print ('Mapping keyboard')
		print ('========================================================')
		print ('--------------------------------------------------------')

		VirtualKeyboard = dict()
		Offset = 0
		Keypath = ['C','C#-Db','D','D#-Eb','E','F','F#-Gb','G','G#-Ab','A','A#-Bb','B']

		for i in range(Offset,KeyCount):

			if i-Offset >= len(Keypath):
				Offset += len(Keypath)

			VirtualKeyboard.update({i:[Keypath[(i-Offset)],False]})

with open('./saved-files/virtual_keyboard.json', 'w') as outfile:
	json.dump(VirKey.VirtualKeyboard, outfile)

print (VirKey.VirtualKeyboard)
print ('--------------------------------------------------------')
print ('--------------------------------------------------------')

#------------------------------------------------------------------------------
#==============================================================================

#------------------------------------------------------------------------------
#==============================================================================
#		Chord list
#==============================================================================

class Chords:

	print ('--------------------------------------------------------')
	print ('Chords')
	print ('========================================================')
	print ('--------------------------------------------------------')

	ChordsDict = {'Power chord':[(2,False),(3,False),(4,False),(5,False),(7,True),(10,False)],
	'Octave':[(-12,False),(3,False),(4,False),(5,False),(7,False),(10,False),(12,True),(24,False)],
	'Suspended2':[(2,True),(7,True)],
	'Suspended4':[(5,True),(7,True)],
	'Major':[(4,True),(7,True),(10,False)],'Minor':[(3,True),(7,True)],
	'Seventh':[(4,True),(7,True),(10,True)],
	'Augmented':[(4,True),(8,True)],
	'Diminished':[(-4,False),(3,True),(6,True)]}

	SpecialNotes = {'!':[36,48,84,96],"'":[95],",":[94],'?':[93],'.':[40],'[bks]':[82,80]}
	SequanceNotes = {36:[40,'[spc]'],40:[36,'[spc]'],47:[43,'[ent]'],43:[47,'[ent]']}

	print ('Power chord - ',ChordsDict['Power chord'])
	print ('Octave - ',ChordsDict['Octave'])
	print ('Suspended2 - ',ChordsDict['Suspended2'])
	print ('Suspended4 - ',ChordsDict['Suspended4'])
	print ('Major - ',ChordsDict['Major'])
	print ('Minor - ',ChordsDict['Minor'])
	print ('Seventh - ',ChordsDict['Seventh'])
	print ('Augmented - ',ChordsDict['Augmented'])
	print ('Diminished - ',ChordsDict['Diminished'])
	print ('--------------------------------------------------------')
	print ('--------------------------------------------------------')

#------------------------------------------------------------------------------
#==============================================================================

#------------------------------------------------------------------------------
#==============================================================================
#		Alphabet
#==============================================================================

class Alphabet:
	try:

		if not os.path.exists("./saved-files"): os.makedirs("./saved-files")
		Passport =  collections.OrderedDict(sorted(json.load(open("./saved-files/Passport.txt")).items()))
		User = Passport['name']


	except:

		Passport = {'name':'anonymous','password':''}
		User = Passport['name']

	print ('Getting files for '+User)
	json.dump(Passport, open("./saved-files/Passport.txt",'w'), sort_keys=True)
	subdirectory = str("./saved-files/"+User+ "-dict")

	try:

		print ('--------------------------------------------------------')
		print ('Loading alphabet')
		print ('========================================================')
		print ('--------------------------------------------------------')

		AlphabetList =  collections.OrderedDict(sorted(json.load(open(str(subdirectory+"/Alphabet.txt"))).items()))
		for key in AlphabetList:

			print (key+' - '+AlphabetList[key])

	except KeyboardInterrupt:

		try:
			sys.exit(0)
		except SystemExit:
			os._exit(0)

	except Exception:
		print ('Loading failed [no such file or directory]')
		print ('--------------------------------------------------------')
		print ('composing alphabet')
		print ('========================================================')
		print ('--------------------------------------------------------')

		if not os.path.exists(subdirectory): os.makedirs(subdirectory)

		AlphabetList = dict()

		for a in VirKey.Keypath:
			for b in Chords.ChordsDict:

				AlphabetList.update({str(a+' '+b):'[empty]'})
				print (a+' '+b+' - '+AlphabetList[str(a+' '+b)])

		json.dump(AlphabetList, open(str(subdirectory+"/Alphabet.txt"),'w'),sort_keys=True)

	print ('--------------------------------------------------------')
	print ('--------------------------------------------------------')

#------------------------------------------------------------------------------
#==============================================================================

#------------------------------------------------------------------------------
#==============================================================================
#		Pathern check
#==============================================================================

class Keythread:
	chordThread = {}
	for i in range(21,120):
		chordThread.update({i:''})
	print ('Keythread ',chordThread);

#------------------------------------------------------------------------------
#==============================================================================

#------------------------------------------------------------------------------
#==============================================================================
#		Pathern check
#==============================================================================

noteLog = []

def check(TimeOfRequest):

	def checkchords(noteCH,TimeOfRequest):
		global keyBuffer
		loopBreak = False

		for special in Chords.SpecialNotes:

			loopBreak = False
			for specialNoteCheck in Chords.SpecialNotes[special]:

				if noteCH in Chords.SpecialNotes[special] and VirKey.VirtualKeyboard[specialNoteCheck][1] == True:
					pass
				else:
					loopBreak = True
					break

			if loopBreak:
				notePattern = ''
			else:

				keyBuffer = 0
				notePattern = special
				sendMsg(str(notePattern),TimeOfRequest)
				break

		for Pattern in Chords.ChordsDict:

			loopBreak = False
			for checkPattern in Chords.ChordsDict[Pattern]:

				if VirKey.VirtualKeyboard[(noteCH+checkPattern[0])][1] == checkPattern[1]:

					pass

				else:

					loopBreak = True
					break

			if loopBreak:

				notePattern = ''

			else:

				keyBuffer = 0
				notePattern = str(VirKey.VirtualKeyboard[noteCH][0]+' '+Pattern)
				sendMsg(str(Alphabet.AlphabetList[notePattern]),TimeOfRequest)
				break

	for i in noteLog:
		Keythread.chordThread[i] = threading.Thread(target=checkchords, args=(i,TimeOfRequest))
		Keythread.chordThread[i].daemon = True
		Keythread.chordThread[i].start()

#------------------------------------------------------------------------------
#==============================================================================

#------------------------------------------------------------------------------
#==============================================================================
#		MIDI
#==============================================================================

pygame.init()
pygame.fastevent.init()
midi.init()

print ('--------------------------------------------------------')
print ('MIDI input output')
print ('========================================================')
print ('--------------------------------------------------------')
print("Default input device is: ")
print ('Default input:',midi.get_default_input_id())
print ('Default output:',midi.get_default_output_id(),'\n')

for i in range(midi.get_count()):

	print (midi.get_device_info(i));

#		Set input
#==============================================================================

try:

	keyboardConf = collections.OrderedDict(sorted(json.load(open("./saved-files/keyboard.json")).items()))
	ipDev = keyboardConf['in']
	opDev = keyboardConf['out']

except:

	print(' !!! WARNING !!! no keyboard configuration file found')
	ipDev = midi.get_default_input_id()
	opDev = midi.get_default_output_id()

x = midi.Input(ipDev,0)

class getX:
	def __getitem__(self,index):
		print (x)

x.read(1)
print(midi.get_device_info(ipDev))

#		Set output
#==============================================================================

player = midi.Output(opDev,0)
player.set_instrument(1,1)
print(midi.get_device_info(opDev))

print ('--------------------------------------------------------')
print ('--------------------------------------------------------')

print ('--------------------------------------------------------')
print ('MIDI')
print ('========================================================')
print ('--------------------------------------------------------')

#------------------------------------------------------------------------------
#==============================================================================

#------------------------------------------------------------------------------
#==============================================================================
#		Server connect
#==============================================================================

try:

	def PKCserver():
		global PKCmsg
		global PKCmidi

		class Namespace(BaseNamespace):

			def on_connect(self):
				print ('Handshake between server and '+str(Alphabet.User))
				socketIO.emit('handshake', str(Alphabet.User))
				print (' --- Server connected --- ')

			def on_disconnect(self):
				print('disconnect')

			def on_reconnect(self):
				print('reconnect')


		socketIO = SocketIO('http://127.0.0.1', 50000, Namespace )
		#socketIO = SocketIO('http://68.66.249.86', 50000, Namespace )
		socketIO.wait(seconds = 1)

		while True:

			if PKCmsg != '':

				socketIO.emit('PKCmsg', PKCmsg)
				PKCmsg = ''

			if PKCmidi != '':

				socketIO.emit('PKCmidi', PKCmidi)
				PKCmidi = ''

	Serverthread = threading.Thread(target=PKCserver)
	Serverthread.daemon = True
	Serverthread.start()

except KeyboardInterrupt:

	try:
		sys.exit(0)
	except SystemExit:
		os._exit(0)

except serverError as err:

	print (' --- '+err+' --- ')

except:

	print (' --- No server --- ')

#------------------------------------------------------------------------------
#==============================================================================

#------------------------------------------------------------------------------
#==============================================================================
#		Send message
#==============================================================================

def sendMsg(msg,TimeOfRequest):
	global PKCmsg
	global lastMsg
	global lastMsgTime
	global capslock
	global senddata

	interval = 0.1

	if (TimeOfRequest-lastMsgTime) <= interval and len(msg) == 1 and msg != '!':

		msg = lastMsg
		senddata = ''

	elif msg == '[cap]' and capslock == False:

		capslock = True

	elif msg == '[cap]' and capslock == True:

		capslock = False

	elif (TimeOfRequest-lastMsgTime) == 0.0 or msg == '[empty]':

		msg = lastMsg
		senddata = ''

	elif (TimeOfRequest-lastMsgTime) <= (interval*3) and msg == '!' and lastMsg != '!':

		senddata = '[bks]","'+msg

	elif (TimeOfRequest-lastMsgTime) <= (interval*3) and msg == 'r' or msg == 'R':

		msg = lastMsg
		senddata = ''

	elif capslock == True and len(msg) == 1:

		senddata = msg.upper()

	else:

		senddata = msg



	PKCmsg = '{"'+Alphabet.User+'":["'+senddata+'"]}'

	sys.stdout.write('\x1b[1A')
	sys.stdout.write('\x1b[2K')
	print (PKCmsg+' at '+str(TimeOfRequest)+' inteval - '+str(TimeOfRequest-lastMsgTime)+' lastmsg['+lastMsg+']')
	lastMsg = msg
	lastMsgTime = TimeOfRequest

print ('--------------------------------------------------------')
print ('interface ready at --- '+str(time.time()-timerStart)+' --- ')
print ('--------------------------------------------------------')
print ('Press ESC to quit the program')
print ('========================================================')
print ('--------------------------------------------------------')
print ('')
#------------------------------------------------------------------------------
#==============================================================================

#------------------------------------------------------------------------------
#==============================================================================
#		Interface
#==============================================================================

#------------------------------------------------------------------------------
#==============================================================================
#		Server connect
#==============================================================================

def QWERTY():
	global Dialog

	while True:

		event = pygame.event.wait()
		if event.type == pygame.KEYDOWN:
			if event.key == pygame.K_ESCAPE or event.unicode == 'q':
				print(' !!! Quit program !!! ')
				time.sleep(5)
				Dialog = False

#QWERTYthread = threading.Thread(target=QWERTY)
#QWERTYthread.daemon = True
#QWERTYthread.start()

keyBuffer = 0
Dialog = True

while Dialog == True:

	if x.poll():

		midiEvent = x.read(1)[0]
		noteSW = midiEvent[0][0]
		note = midiEvent[0][1]
		vel = midiEvent[0][2]

		if vel != 0:

			if VirKey.VirtualKeyboard[note][1] == False:
				sys.stdout.write('\x1b[1A')
				sys.stdout.write('\x1b[2K')
				print(midiEvent)
				PKCmidi = '{"'+Alphabet.User+'":'+str(midiEvent)+'}'
				VirKey.VirtualKeyboard[note][1] = True
				noteLog.append(note)

				if note in Chords.SequanceNotes and keyBuffer == 0:

					keyBuffer = note
					check((time.time()))

				elif keyBuffer != 0 and note != Chords.SequanceNotes[keyBuffer][0]:

					keyBuffer = 0
					check((time.time()))

				elif keyBuffer != 0 and note == Chords.SequanceNotes[keyBuffer][0]:

					notePattern = Chords.SequanceNotes[keyBuffer][1]
					sendMsg(str(notePattern),(time.time()))
					keyBuffer = 0

				else:

					check((time.time()))

		elif note != 0:

			if VirKey.VirtualKeyboard[note][1] == True:
				PKCmidi = '{"'+Alphabet.User+'":'+str(midiEvent)+'}'
				VirKey.VirtualKeyboard[note][1] = False

				try:
					noteLog.remove(note)
				except:
					sys.stdout.write('\x1b[1A')
					sys.stdout.write('\x1b[2K')
					print (str(note)+' not in log')

#------------------------------------------------------------------------------
#==============================================================================
player.abort()
player.close()
x.close()
midi.quit()
pygame.quit()
