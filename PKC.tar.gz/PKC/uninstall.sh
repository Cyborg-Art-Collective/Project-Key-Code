#!/bin/bash

echo $'\n\t ------ Type your computers password to start the uninstallation ------ \n '
sudo touch log-files/sudo-Log.txt
sudo rm -rf log-files/sudo-Log.txt

echo $'\n\n\t Uninstalling software: \n' >> log-files/run-Log.txt
date '+%Y-%m-%d %H:%M:%S' >> log-files/run-Log.txt
echo $'\n\n' >> log-files/run-Log.txt
echo ${OSSTR} >> log-files/installation-Log.txt

echo '------------------------------------------------'
echo '================================================'
echo 'uninstalling pygame...'
echo '================================================'
echo $'\n\t ------ pygame ------ \n' >> log-files/installation-Log.txt

  brew uninstall -f --ignore-dependencies sdl_ttf 2>&1 | tee -a log-files/installation-Log.txt
  brew uninstall -f --ignore-dependencies sdl_mixer 2>&1 | tee -a log-files/installation-Log.txt
  brew uninstall -f --ignore-dependencies sdl_image 2>&1 | tee -a log-files/installation-Log.txt
  brew uninstall -f --ignore-dependencies sdl 2>&1 | tee -a log-files/installation-Log.txt
  brew uninstall -f --ignore-dependencies portmidi 2>&1 | tee -a log-files/installation-Log.txt
  brew uninstall -f --ignore-dependencies mercurial 2>&1 | tee -a log-files/installation-Log.txt

  sudo pip uninstall -r -y numpy matplotlib 2>&1 | tee -a log-files/installation-Log.txt
  sudo pip uninstall -r -y pygame 2>&1 | tee -a log-files/installation-Log.txt


echo '------------------------------------------------'
echo '================================================'
echo 'uninstalling jack...'
echo '================================================'
echo $'\n\t ------ jack ------ \n' >> log-files/installation-Log.txt

  brew uninstall -f --ignore-dependencies 2>&1 | tee -a log-files/installation-Log.txt

echo '------------------------------------------------'
echo '================================================'
echo 'uninstalling Socketio_client...'
echo '================================================'
echo $'\n\t ------ Socketio_client ------ \n' >> log-files/installation-Log.txt

  sudo sudo pip uninstall -r -y Socketio_client 2>&1 | tee -a log-files/installation-Log.txt

echo '------------------------------------------------'
echo '================================================'
echo 'uninstalling NodeJS...'
echo '================================================'
echo $'\n\t ------ NodeJS ------ \n' >> log-files/installation-Log.txt

  brew uninstall -f --ignore-dependencies npm 2>&1 | tee -a log-files/installation-Log.txt
  brew uninstall -f --ignore-dependencies node 2>&1 | tee -a log-files/installation-Log.txt

echo '------------------------------------------------'
echo '================================================'
echo 'uninstalling NodeJS...'
echo '================================================'
echo $'\n\t ------ NodeJS2 ------ \n' >> log-files/installation-Log.txt

  brew uninstall -f --ignore-dependencies node 2>&1 | tee -a log-files/installation-Log.txt
  brew uninstall -f --ignore-dependencies npm 2>&1 | tee -a log-files/installation-Log.txt

echo '------------------------------------------------'
echo '================================================'
echo 'uninstalling python2...'
echo '================================================'
echo $'\n\t ------ python2 ------ \n' >> log-files/installation-Log.txt

  sudo sudo pip uninstall -r -y pip setuptools 2>&1 | tee -a log-files/installation-Log.txt
  brew uninstall -f --ignore-dependencies python2 2>&1 | tee -a log-files/installation-Log.txt

echo '------------------------------------------------'
echo '================================================'
echo 'uninstalling homebrew...'
echo '================================================'
echo $'\n\t ------ Homebrew  ------ \n' >> log-files/installation-Log.txt

  /usr/bin/ruby -e "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/master/uninstall)"

echo '------------------------------------------------'
echo '================================================'
echo 'removing files...'
echo '================================================'

rm -rf saved-files
rm -rf PKC
rm -rf run_program.command
rm -rf update.sh
rm -rf log-files

echo '------------------------------------------------'
echo '================================================'
echo $'\n\nYour computer will explode in 5 seconds...'
sleep 1
echo $'\n\t 1.'
sleep 1
echo $'\t 2.'
sleep 1
echo $'\t 3.'
sleep 1
echo $'\t 4.'
sleep 1
echo $'\t 5.'
echo $'\n\n\tBOOM!!!!\n\n'
echo '================================================'
rm -rf uninstall.sh
osascript -e 'tell application "Terminal" to quit'
