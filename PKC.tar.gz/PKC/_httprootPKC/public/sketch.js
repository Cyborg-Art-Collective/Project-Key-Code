var socket;
var dialog1 = '';
var dialog2 = '';

function preload(){

  //socket
  socket = io.connect('http://127.0.0.1:50000')

  //CyArCo
  socket.on('CyArCo-char', CyArCoMsg);
  //socket.on('CyArCo-midi', player);

  socket.on('Inforeturn',Info);
  textFile = loadStrings("num.txt");
}

//----------------------------------------------------------------------------------------------
//setup
//----------------------------------------------------------------------------------------------
//==============================================================================================
function setup() {

  //dialog
  dimentions = {w:windowWidth,h:windowHeight};
  dialog = createCanvas(round((dimentions.w/100)*50), dimentions.h);
  dialog.parent('dialog');
  dialog.style('display', 'block');
  dialog.style('-webkit-box-shadow',' 2px 2px 4px 4px rgba(16,16,16,0.15)');
  dialog.style('-moz-box-shadow',' 2px 2px 4px 4px rgba(16,16,16,0.15)');
  dialog.style('box-shadow',' 2px 2px 4px 4px rgba(16,16,16,0.15)');

  dialog.position(round((dimentions.w/100)*25), 0);
  background(255,255,255);

  //Dialogfield1
  dialogfield1 = createDiv("");
  dialogfield1.style('display', 'block');
  dialogfield1.style('word-wrap', 'break-word');
  dialogfield1.position(round((dimentions.w/100)*27), round((dimentions.h/100)*7));
  dialogfield1.size(round((dimentions.w/100)*46), round((dimentions.h/100)*41));

}

//----------------------------------------------------------------------------------------------
//server events
//----------------------------------------------------------------------------------------------
//==============================================================================================
function CyArCoMsg(data){
  if(data == '[bks]'){

    dialog1 = dialog1.slice(0, -1);

  }else if(data == '[ent]'){

    dialog1 += "<br/>";

  }else if(data == '[spc]'){

    dialog1 += " ";

  }else{
    dialog1 += data;
  }

  dialogfield1.html(dialog1);
  console.log('message - '+data);
}

//----------------------------------------------------------------------------------------------
//resize and draw
//----------------------------------------------------------------------------------------------
//==============================================================================================

function windowResized() {

  //dialog
  dimentions = {w:windowWidth,h:windowHeight};

  dialog.size(round((dimentions.w/100)*50), dimentions.h);
  dialog.position(round((dimentions.w/100)*25), 0);

  //connectconter
  connectionCounter.position(round((dimentions.w/100)*45), round((dimentions.h/100)*92));
  connectionCounter.size(round((dimentions.w/100)*40), round((dimentions.h/100)*5));

  //Dialogfield1
  dialogfield1.position(round((dimentions.w/100)*27), round((dimentions.h/100)*7));
  dialogfield1.size(round((dimentions.w/100)*46), round((dimentions.h/100)*41));

}

function draw() {
}

function Info(data){
  connectionCounter.html("There are "+data+"<br/>visitours online");
}
