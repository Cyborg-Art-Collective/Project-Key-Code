var PKCport = 50000;
console.log("listning at port [ "+PKCport+" ]");

//require
var fs = require('fs');
var express = require('express');
var socket = require('socket.io');

//rederect server
var app = express();
var PKCclientserver = app.listen(PKCport);
app.use(express.static('./public'));
var ioClient = socket(PKCclientserver);
ioClient.sockets.on('connection', clientconnect);

console.log("okay, I'm listning");

function clientconnect(socket){

  console.log("New connection [ "+socket.id+" ]");

  //PKC server events
  socket.on('handshake',handshake);
  socket.on('PKCmsg',PKCmsg);
  socket.on('PKCmidi',PKCmidi);
  socket.on('stream',stream);
  console.log("sockets ready");

  //rederect server events
  socket.on('Inforequest', sendInfo);

  //general server events
  socket.on('disconnect', clientLost);

  socket.broadcast.emit('Inforeturn', 'new connection!!!');
  console.log("broadcast to all");

  //PKC server functions
  function handshake(data){

    console.log("PKC client is --- [ "+data+" ] --- ");

  }

  function PKCmsg(data){

    data = JSON.parse(data);

    for(var PKCmsgkey in data){
      for (var PKCmsgitem of data[PKCmsgkey]) {

        socket.broadcast.emit(PKCmsgkey+"-char", PKCmsgitem);
        console.log("PKCmsg --- "+PKCmsgitem+" --- ");

      }
    }
  }

  function PKCmidi(data){

    data = JSON.parse(data);

    for(var PKCmidikey in data){

      socket.broadcast.emit(PKCmidikey+"-midi", data[PKCmidikey]);
      console.log("PKCmidi ---"+data[PKCmidikey]+"--- ");

    }
  }

  function stream(data){

    var ua = new Uint8Array(data.length);

    Array.prototype.forEach.call(data, function (ch, i) {
      ua[i] = ch.charCodeAt(0);
    });

    console.log(ua);

  }

  //rederect server functions
  function sendInfo(){

    console.log("information request");
    socket.broadcast.emit('Inforeturn', 'new connection!!!');

  }

  //general server functions
  function clientLost() {

    console.log("connection [ "+socket.id+" ] lost");
    socket.broadcast.emit('Inforeturn', 'new connection!!!');

  }
}
console.log("Project Key Code server ready");
